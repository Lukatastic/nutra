//
//  NutriaApp.swift
//  Nutria
//
//  Created by Jones Mays II on 4/27/24.
//

import SwiftUI

@main
struct NutriaApp: App {
    
    @StateObject private var userDataService = UserDataService()
    @StateObject var machineModel = MachineLearningDataModel()
    
    var body: some Scene {
        
        WindowGroup {
            
            ZStack(){
                
                TabViewManager(userDataService: userDataService, machineModel: machineModel)
               
                if (userDataService.isContentViewOpen){
                    ContentView(userDataService: userDataService)
                }
            }
            
        }
    }
}

